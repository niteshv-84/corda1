package com.example.contract;

import net.corda.core.contracts.*;
import net.corda.core.crypto.CompositeKey;
import net.corda.core.crypto.Party;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * Created by Nitesh on 2/4/2017.
 */
public class TransactionStates implements ContractState {

    private List<StateAndRef<LinearState>> inputStates;
    private List<TransactionState<ContractState>> outputStates;

    private final GrossTradeContract contract;

    public TransactionStates(){
        inputStates = new ArrayList<>();
        outputStates = new ArrayList<>();
        contract = new GrossTradeContract();
    }

    public boolean addInputState(StateAndRef<LinearState> inputState){
        return inputStates.add(inputState);
    }

    public boolean addInputStates(List<StateAndRef<LinearState>> inputStatesList){
        return inputStates.addAll(inputStatesList);
    }

    public boolean addOutputState(TransactionState<ContractState> outputState){
        return outputStates.add(outputState);
    }

    public boolean addOutputStates(List<TransactionState<ContractState>> outputStatesList){
        return outputStates.addAll(outputStatesList);
    }

    public List<StateAndRef<LinearState>> getInputStates(){
        return inputStates;
    }

    public List<TransactionState<ContractState>> getOutputStates(){
        return outputStates;
    }


    @Override
    public Contract getContract() {
        return this.contract;
    }


    @Override
    public List<CompositeKey> getParticipants() {
        return null;
    }
}
