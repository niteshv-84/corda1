package com.example.contract;

import com.example.contract.GrossTradeContract.Commands.Place;
import com.example.model.GrossTrade;
import com.example.model.TradeStatusEnum;
import net.corda.core.contracts.*;
import net.corda.core.crypto.CompositeKey;
import net.corda.core.crypto.Party;
import net.corda.core.transactions.TransactionBuilder;

import java.security.PublicKey;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static java.util.stream.Collectors.toList;

// TODO: Implement QueryableState and add ORM code (to match Kotlin example).

/**
 * The state object that we will use to record the agreement of a valid purchase order issued by a buyer to a seller.
 * <p>
 * There are a few key state interfaces, the most fundamental of which is [ContractState]. We have defined other
 * interfaces for different requirements. In this case, we are implementing a [DealState] which defines a few helper
 * properties and methods for managing states pertaining to deals.
 */
public class GrossTradeState implements DealState  {

    private final GrossTrade grossTrade;
    private final Party buyer;

    private final Party seller;
    private final GrossTradeContract contract;
    private final UniqueIdentifier linearId;


    private final TradeStatusEnum tradeStatusEnum;

    public GrossTradeState(
            GrossTrade grossTrade,
            TradeStatusEnum tradeStatusEnum,
            Party buyer,
            Party seller,
            GrossTradeContract contract) {
        this.grossTrade = grossTrade;
        this.tradeStatusEnum = tradeStatusEnum;
        this.buyer = buyer;
        this.seller = seller;
        this.contract = contract;
        this.linearId = new UniqueIdentifier(
                grossTrade.getTradeId(),
                UUID.randomUUID());
    }

    //Added new constructor for LinearID

    public GrossTradeState(
            GrossTrade grossTrade,
            TradeStatusEnum tradeStatusEnum,
            Party buyer,
            Party seller,
            UniqueIdentifier uID,
            GrossTradeContract contract) {
        this.grossTrade = grossTrade;
        this.tradeStatusEnum = tradeStatusEnum;
        this.buyer = buyer;
        this.seller = seller;
        this.contract = contract;
        this.linearId = uID;
    }

    public GrossTradeState copy(TradeStatusEnum newState){
        return new GrossTradeState(this.grossTrade ,newState,  this.buyer , this.getSeller() , this.getLinearId(), this.contract);
    }
    public GrossTrade getGrossTrade() {
        return grossTrade;
    }

    public Party getBuyer() {
        return buyer;
    }

    public Party getSeller() {
        return seller;
    }

    @Override
    public GrossTradeContract getContract() {
        return contract;
    }

    @Override
    public UniqueIdentifier getLinearId() {
        return linearId;
    }

    @Override
    public String getRef() {
        return linearId.getExternalId();
    }

    @Override
    public List<Party> getParties() {
        return Arrays.asList(buyer, seller);
    }

    @Override
    public List<CompositeKey> getParticipants() {
        return getParties()
                .stream()
                .map(Party::getOwningKey)
                .collect(toList());
    }

    public TradeStatusEnum getTradeStatusEnum() {
        return tradeStatusEnum;
    }

        /**
     * This returns true if the state should be tracked by the vault of a particular node. In this case the logic is
     * simple; track this state if we are one of the involved parties.
     */
    @Override
    public boolean isRelevant(Set<? extends PublicKey> ourKeys) {
        final List<PublicKey> partyKeys = getParties()
                .stream()
                .flatMap(party -> party.getOwningKey().getKeys().stream())
                .collect(toList());
        return ourKeys
                .stream()
                .anyMatch(partyKeys::contains);

    }

    /**
     * Helper function to generate a new Issue() purchase order transaction. For more details on building transactions
     * see the API for [TransactionBuilder] in the JavaDocs.
     * https://docs.corda.net/api/net.corda.core.transactions/-transaction-builder/index.html
     */
    @Override
    public TransactionBuilder generateAgreement(Party notary) {
        return new TransactionType.General.Builder(notary)
                .withItems(this, new Command(new Place(), getParticipants()));
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GrossTradeState)) return false;

        GrossTradeState that = (GrossTradeState) o;

        if (!getGrossTrade().equals(that.getGrossTrade())) return false;
        if (!getBuyer().equals(that.getBuyer())) return false;
        if (!getSeller().equals(that.getSeller())) return false;
      //  if (!getContract().equals(that.getContract())) return false;
       // if (getLinearId() != null ? !getLinearId().equals(that.getLinearId()) : that.getLinearId() != null)
         //   return false;
        return getTradeStatusEnum() == that.getTradeStatusEnum();
    }

    @Override
    public int hashCode() {
        int result = getGrossTrade().hashCode();
        result = 31 * result + getBuyer().hashCode();
        result = 31 * result + getSeller().hashCode();
       // result = 31 * result + getContract().hashCode();
       // result = 31 * result + (getLinearId() != null ? getLinearId().hashCode() : 0);
        result = 31 * result + getTradeStatusEnum().hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "GrossTradeState{" +
                "grossTrade=" + grossTrade +
                ", buyer=" + buyer +
                ", seller=" + seller +
                ", contract=" + contract +
                ", linearId=" + linearId +
                ", tradeStatusEnum=" + tradeStatusEnum +
                '}';
    }

    public String getGroupingKey(){
        return this.getGrossTrade().getSecurityID() + this.getGrossTrade().getCurrency().getDisplayName();
    }
}