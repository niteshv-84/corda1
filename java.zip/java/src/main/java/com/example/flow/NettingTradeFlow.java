package com.example.flow;

import co.paralleluniverse.fibers.Suspendable;
import com.example.contract.GrossTradeContract;
import com.example.contract.GrossTradeState;
import com.example.contract.TransactionStates;
import com.example.model.GrossTrade;
import com.example.model.TradeStatusEnum;
import com.example.util.NetTradeCalculator;
import net.corda.core.contracts.*;
import net.corda.core.crypto.CompositeKey;
import net.corda.core.crypto.CryptoUtilities;
import net.corda.core.crypto.DigitalSignature;
import net.corda.core.crypto.Party;
import net.corda.core.flows.FlowLogic;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.transactions.WireTransaction;
import net.corda.core.utilities.ProgressTracker;
import net.corda.flows.NotaryFlow;

import java.math.BigDecimal;
import java.security.KeyPair;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

import static kotlin.collections.CollectionsKt.single;

/**
 * This is the "Hello World" of flows!
 *
 * It is a generic flow which facilitates the workflow required for two parties; an [NettingInitiator] and an [Acceptor],
 * to come to an agreement about some arbitrary data (in this case, a [InterCompanyTrade]) encapsulated within a [DealState].
 *
 * As this is just an example there's no way to handle any counter-proposals. The [Acceptor] always accepts the
 * proposed state assuming it satisfies the referenced [Contract]'s issuance constraints.
 *
 * These flows have deliberately been implemented by using only the call() method for ease of understanding. In
 * practice we would recommend splitting up the various stages of the flow into sub-routines.
 *
 * NB. All methods called within the [FlowLogic] sub-class need to be annotated with the @Suspendable annotation.
 *
 * The flows below have been heavily commented to aid your understanding. It may also be worth reading the CorDapp
 * tutorial documentation on the Corda docsite (https://docs.corda.net) which includes a sequence diagram which clearly
 * explains each stage of the flow.
 */
public class NettingTradeFlow {
    public static class NettingInitiator extends FlowLogic<NetFlowResult> {


        private final Party nodeA;

        private final Party nodeB;

        private final Party otherParty;
        // The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
        // checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call()
        // function.
        private final ProgressTracker progressTracker = new ProgressTracker(
                MATCH_TRADE,
                CONSTRUCTING_OFFER,
                SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION,
                VERIFYING,
                SIGNING,
                NOTARY,
                RECORDING,
                SENDING_FINAL_TRANSACTION
        );
        private static final ProgressTracker.Step MATCH_TRADE = new ProgressTracker.Step(
                "Check if there is a matching trade.");
        private static final ProgressTracker.Step CONSTRUCTING_OFFER = new ProgressTracker.Step(
                "Constructing proposed purchase order.");
        private static final ProgressTracker.Step SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION = new ProgressTracker.Step(
                "Sending purchase order to seller for review, and receiving partially signed transaction from seller in return.");
        private static final ProgressTracker.Step VERIFYING = new ProgressTracker.Step(
                "Verifying signatures and contract constraints.");
        private static final ProgressTracker.Step SIGNING = new ProgressTracker.Step(
                "Signing transaction with our private key.");
        private static final ProgressTracker.Step NOTARY = new ProgressTracker.Step(
                "Obtaining notary signature.");
        private static final ProgressTracker.Step RECORDING = new ProgressTracker.Step(
                "Recording transaction in vault.");
        private static final ProgressTracker.Step SENDING_FINAL_TRANSACTION = new ProgressTracker.Step(
                "Sending fully signed transaction to seller.");


        public NettingInitiator(Party nodeA, Party nodeB, Party otherParty) {
            this.nodeA = nodeA;
            this.nodeB = nodeB;
            this.otherParty = otherParty;
        }


        @Override
        public ProgressTracker getProgressTracker() {
            return progressTracker;
        }

        @Suspendable
        @Override
        public NetFlowResult call() {
            try {
                System.out.println("IN NETTING TRADE FLOW");
                // Prep.
                // Obtain a reference to our key pair. Currently, the only key pair used is the one which is registered with
                // the NetWorkMapService. In a future milestone release we'll implement HD key generation such that new keys
                // can be generated for each transaction.
                final KeyPair myKeyPair = getServiceHub().getLegalIdentityKey();
                // Obtain a reference to the notary we want to use and its public key.
                final Party notary = single(getServiceHub().getNetworkMapCache().getNotaryNodes()).getNotaryIdentity();
                final CompositeKey notaryPubKey = notary.getOwningKey();


                // Stage 1.
                progressTracker.setCurrentStep(CONSTRUCTING_OFFER);


                List<StateAndRef<ContractState>> vaultStates = getServiceHub().getVaultService().getCurrentVault().getStates();
                System.out.println("\n\n\n\nFetched states from db\n\n\n" + vaultStates);

                Map<UniqueIdentifier, StateAndRef<LinearState>> linearStates = getServiceHub().getVaultService().getLinearHeads();
                System.out.println("\n\n\n\nFetched linear states from db\n\n\n" + linearStates);

                //get all linear heads that are matched
               Map<String, GrossTradeState> outputSettledMap = new HashMap<String, GrossTradeState>();

                List<StateAndRef<LinearState>> inputMatchingStates = new ArrayList<StateAndRef<LinearState>>();
                List<GrossTradeState> outputNettedStates = new ArrayList<GrossTradeState>();

                for (Map.Entry<UniqueIdentifier, StateAndRef<LinearState>> linearState : linearStates.entrySet()) {
                    LinearState lState = linearState.getValue().getState().getData();
                    if (lState instanceof GrossTradeState) {
                        GrossTradeState grossTradeState = (GrossTradeState) lState;
                        boolean netTrade = false;
                        if (grossTradeState.getTradeStatusEnum() == TradeStatusEnum.MATCHED) {
                            inputMatchingStates.add(linearState.getValue());
                            //update the state to NETTED
                            GrossTradeState nettedState = grossTradeState.copy(TradeStatusEnum.CONSUMED);
                            outputNettedStates.add(nettedState);

                          GrossTradeState aggregatedNettedState = outputSettledMap.get(grossTradeState.getGroupingKey());

                                if (aggregatedNettedState == null) {

                                    GrossTrade trade = new GrossTrade();
                                   // trade.setAmount(new BigDecimal("0"));
                                    trade.setCurrency(Currency.getInstance("USD"));
                                    trade.setPrice(new BigDecimal("0"));
                                    trade.setQuantity(new BigDecimal("0"));
                                    trade.setSecurityID(nettedState.getGrossTrade().getSecurityID());
                                    trade.setAmount(trade.getPrice().multiply(trade.getQuantity()));
                                    System.out.println("");

                                    trade.setTradeId("NET-" + System.currentTimeMillis());
                                    trade.setTradeDate(new Date());
                                    trade.setValueDate(new Date());

                                    aggregatedNettedState = new GrossTradeState(trade, TradeStatusEnum.NETTED, nodeA, nodeB, new GrossTradeContract());

                            }

                            outputSettledMap.put(grossTradeState.getGroupingKey(), NetTradeCalculator.aggrigateNetTrades(aggregatedNettedState,nettedState));
                        }
                    }
                }

               // GrossTradeState aggrigatedNetState = NetTradeCalculator.aggrigateNetTrades(outputNettedStates);
                System.out.println("\n\n\n\nOUTPUT NETTED STATES\n\n\n" + outputNettedStates);
                System.out.println("\n\n\n\nOUTPUT AGGRIGATED_NET MAP\n\n\n" + outputSettledMap);
                //group states by party, counterparty, product, currency
                //aggregate on quantity and amount

                //all linear heads that are matched change to netted
                //create new netted output states of type instruction
                TransactionBuilder builder = new TransactionType.General.Builder(notary);
                //builder.setNotary(notary);
//                for (StateAndRef<LinearState> inputMatchingState: inputMatchingStates){
//                    builder.addInputState(inputMatchingState);
//                }
//                for (GrossTradeState outputNettedState: outputNettedStates){
//                    builder.addOutputState(outputNettedState, notary);
//                }
//                for (Map.Entry<String, GrossTradeState> outputSettledState: outputSettledMap.entrySet()) {
//                    builder.addOutputState(outputSettledState.getValue(), notary);
//                }

                TransactionStates  netTradeTransactionStates = new TransactionStates();
                List<StateRef> inputStates = new ArrayList<StateRef>();
                for (StateAndRef<LinearState> inputMatchingState : inputMatchingStates) {
                    inputStates.add(inputMatchingState.getRef());
                    builder.addInputState(inputMatchingState);
                    netTradeTransactionStates.addInputState(inputMatchingState);
                }

                List<TransactionState<ContractState>> outputStates = new ArrayList<TransactionState<ContractState>>();
                for (GrossTradeState outputNettedState : outputNettedStates) {
                    TransactionState<ContractState> trxState = new TransactionState(outputNettedState, notary);
                    outputStates.add(trxState);
                    builder.addOutputState(outputNettedState);
                    netTradeTransactionStates.addOutputState(trxState);

                }

                for (Map.Entry<String, GrossTradeState> outputSettledState : outputSettledMap.entrySet()) {

                    TransactionState<ContractState> trxState = new TransactionState(outputSettledState.getValue(), notary);
                    outputStates.add(trxState);
                    builder.addOutputState(outputSettledState.getValue());
                    netTradeTransactionStates.addOutputState(trxState);
                }

                //Create dummy State as some states not getting stored
                GrossTrade trade = new GrossTrade();
                // trade.setAmount(new BigDecimal("0"));
                trade.setCurrency(Currency.getInstance("USD"));
                trade.setPrice(new BigDecimal("0"));
                trade.setQuantity(new BigDecimal("0"));
                trade.setSecurityID("ABC");
                trade.setAmount(trade.getPrice().multiply(trade.getQuantity()));
                System.out.println("");

                trade.setTradeId("NET-" + System.currentTimeMillis());
                trade.setTradeDate(new Date());
                trade.setValueDate(new Date());

                GrossTradeState dummyState1 = new GrossTradeState(trade, TradeStatusEnum.NETTED, nodeA, nodeB, new GrossTradeContract());

                TransactionState<ContractState> dummyTrxState1 = new TransactionState(dummyState1, notary);

                builder.addOutputState(dummyState1);
                outputStates.add(dummyTrxState1);

                trade = new GrossTrade();
                // trade.setAmount(new BigDecimal("0"));
                trade.setCurrency(Currency.getInstance("USD"));
                trade.setPrice(new BigDecimal("0"));
                trade.setQuantity(new BigDecimal("0"));
                trade.setSecurityID("ABC");
                trade.setAmount(trade.getPrice().multiply(trade.getQuantity()));
                System.out.println("");

                trade.setTradeId("NET-" + System.currentTimeMillis());
                trade.setTradeDate(new Date());
                trade.setValueDate(new Date());

                GrossTradeState dummyState2 = new GrossTradeState(trade, TradeStatusEnum.NETTED, nodeA, nodeB, new GrossTradeContract());

                TransactionState<ContractState> dummyTrxState2 = new TransactionState(dummyState1, notary);

                builder.addOutputState(dummyState2);
                outputStates.add(dummyTrxState2);



//                TransactionBuilder builder = new TransactionBuilder(null, notary, inputStates,
//                        null, outputStates, null, null, null);
//                builder.setNotary(notary);

                builder.setTime(getServiceHub().getClock().instant(), Duration.ofSeconds(60));
                builder.signWith(getServiceHub().getLegalIdentityKey());
                //builder.
                System.out.println("\n\n\n\nHERE 2 B \n\n\n" + builder.toString());


                //final TransactionState offerMessage = new TransactionState<ContractState>(grossTradeState, notary);
              //  System.out.println("\n\n\n\nFINAL OUTPUT STATES\n\n\n" + outputSettledMap);

                System.out.println("\n\n\n\nFINAL FIRST OUTPUT STATE\n\n\n" + outputStates.get(0));

                System.out.println("\n\n\n\nSENDING MESSAGE TO COUNTER PARTY\n" +netTradeTransactionStates );
                final TransactionState offerMessage = outputStates.get(0);

             //   final TransactionState offerMessage = new TransactionState<ContractState>(matchedTradeState, notary);

                // Stage 2.
                progressTracker.setCurrentStep(SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION);
                // Send the state across the wire to the designated counterparty.
                // -----------------------
                // Flow jumps to Acceptor.
                // -----------------------
                // Receive the partially signed transaction off the wire from the other party.
                final SignedTransaction ptx = sendAndReceive(SignedTransaction.class, otherParty, outputStates )
                        .unwrap(data -> data);

                System.out.println("\n\n\n\nAFTER RECEIVING TRANSACTION OUTPUT STATES\n" + ptx.getTx().getOutputs());


                // Stage 7.
                progressTracker.setCurrentStep(VERIFYING);
                // Check that the signature of the other party is valid.
                // Our signature and the Notary's signature are allowed to be omitted at this stage as this is only a
                // partially signed transaction.
                final WireTransaction wtx = ptx.verifySignatures(CryptoUtilities.getComposite(myKeyPair.getPublic()), notaryPubKey);

/*
                wtx.getInputs().addAll(inputStates);
                wtx.getOutputs().clear();
                wtx.getOutputs().addAll(outputStates);



                System.out.println("\n\nWTX Inputs:\n "+ wtx.getInputs());
                System.out.println("\n WTX Outputs: \n"+ wtx.getOutputs());

                ptx.getTx().getInputs().addAll(inputStates);
                ptx.getTx().getOutputs().clear();
                ptx.getTx().getOutputs().addAll(outputStates);*/

                System.out.println("\n\nPTX Inputs:\n "+ ptx.getTx().getInputs());
                System.out.println("\n\n PTX Outputs: \n"+ ptx.getTx().getOutputs());
                // Run the contract's verify function.
                // We want to be sure that the PurchaseOrderState agreed upon is a valid instance of an PurchaseOrderContract, to do
                // this we need to run the contract's verify() function.
                System.out.println("Before Verifying");
                wtx.toLedgerTransaction(getServiceHub()).verify();
                System.out.println("After Verifying contract");
                // Stage 8.
                progressTracker.setCurrentStep(SIGNING);
                // Sign the transaction with our key pair and add it to the transaction.
                // We now have 'validation consensus'. We still require uniqueness consensus.
                // Technically validation consensus for this type of agreement implicitly provides uniqueness consensus.
                final DigitalSignature.WithKey mySig = CryptoUtilities.signWithECDSA(myKeyPair, ptx.getId().getBytes());
                final SignedTransaction vtx = ptx.plus(mySig);

                // Stage 9.
                progressTracker.setCurrentStep(NOTARY);
                // Obtain the notary's signature.
                // We do this by firing-off a sub-flow. This illustrates the power of protocols as reusable workflows.
                final DigitalSignature.WithKey notarySignature = subFlow(new NotaryFlow.Client(vtx, NotaryFlow.Client.Companion.tracker()), false);
                // Add the notary signature to the transaction.
                final SignedTransaction ntx = vtx.plus(notarySignature);


                // Stage 10.
                progressTracker.setCurrentStep(RECORDING);

                System.out.println("\n\n Before Recording Transaction Input States: \n"+ntx.getTx().getInputs());
                System.out.println("\n\n Before Recording Transaction Output States: \n"+ntx.getTx().getOutputs());
                // Record the transaction in our vault.
                getServiceHub().recordTransactions(Collections.singletonList(ntx));

                // Stage 11.
                progressTracker.setCurrentStep(SENDING_FINAL_TRANSACTION);
                // Send a copy of the transaction to our counter-party.
                send(otherParty, ntx);

              /*  System.out.println("* * * DB Results in vault* * *");

                 vaultStates = getServiceHub().getVaultService().getCurrentVault().getStates();

                for (StateAndRef stateAndRef : vaultStates) {
                    //  System.out.println("State: " + stateAndRef);
                    TransactionState<GrossTradeState> transactionState = stateAndRef.getState();
                    GrossTradeState tradeState = transactionState.getData();

                    System.out.println("\n \n TradeState from Database: " + tradeState);
                }*/

                System.out.println("* * * DB Results in vault* * *");

                List<StateAndRef<ContractState>> vaultStatess = getServiceHub().getVaultService().getCurrentVault().getStates();

                for (StateAndRef stateAndRef : vaultStatess) {
                    //  System.out.println("State: " + stateAndRef);
                    TransactionState<GrossTradeState> transactionState = stateAndRef.getState();
                    GrossTradeState tradeState = transactionState.getData();

                    System.out.println("\n \n TradeState from Database: " + tradeState);
                }


            } catch (Throwable t) {
                t.printStackTrace(System.out);
            }
            return new NetFlowResult.Success(String.format("Netted Flow on Ledgar."));
        }
    }

    /**
     * The flow logic is encapsulated within the call() method.
     */

    public static class Acceptor extends FlowLogic<NetFlowResult> {

        private final Party otherParty;
        private final ProgressTracker progressTracker = new ProgressTracker(
                WAIT_FOR_AND_RECEIVE_PROPOSAL,
                GENERATING_TRANSACTION,
                SIGNING,
                SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE,
                VERIFYING_TRANSACTION,
                RECORDING
        );

        private static final ProgressTracker.Step WAIT_FOR_AND_RECEIVE_PROPOSAL = new ProgressTracker.Step(
                "Receiving proposed purchase order from buyer.");
        private static final ProgressTracker.Step GENERATING_TRANSACTION = new ProgressTracker.Step(
                "Generating transaction based on proposed purchase order.");
        private static final ProgressTracker.Step SIGNING = new ProgressTracker.Step(
                "Signing proposed transaction with our private key.");
        private static final ProgressTracker.Step SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE = new ProgressTracker.Step(
                "Sending partially signed transaction to buyer and wait for a response.");
        private static final ProgressTracker.Step VERIFYING_TRANSACTION = new ProgressTracker.Step(
                "Verifying signatures and contract constraints.");
        private static final ProgressTracker.Step RECORDING = new ProgressTracker.Step(
                "Recording transaction in vault.");

        public Acceptor(Party otherParty) {
            this.otherParty = otherParty;
        }

        @Override
        public ProgressTracker getProgressTracker() {
            return progressTracker;
        }

        @Suspendable
        @Override
        public NetFlowResult call() {
            try {

                System.out.println("\n\n\n\nSTARTING RECEIVING FLOW\n"  );
                // Prep.
                // Obtain a reference to our key pair.
                final KeyPair keyPair = getServiceHub().getLegalIdentityKey();

                final Party notary = single(getServiceHub().getNetworkMapCache().getNotaryNodes()).getNotaryIdentity();
                final CompositeKey notaryPubKey = notary.getOwningKey();

                System.out.println("\n BEFORE WAITING FOR RECEIVE: "+notaryPubKey);
                // Stage 3.
                progressTracker.setCurrentStep(WAIT_FOR_AND_RECEIVE_PROPOSAL);
                // All messages come off the wire as UntrustworthyData. You need to 'unwrap' it. This is an appropriate
                // place to perform some validation over what you have just received.
               /* final TransactionState<TransactionStates> message = this.receive(TransactionState.class, otherParty)
                        .unwrap(data -> (TransactionState<TransactionStates>) data);*/

                final ArrayList<TransactionState<GrossTradeState>> message = this.receive(ArrayList.class, otherParty)
                        .unwrap(data -> (ArrayList<TransactionState<GrossTradeState>>) data);

                System.out.println("* * *" + message);


                System.out.println("\n\n AFTER RECEIVING MESSAGE: "+message);
                // Stage 4.
                progressTracker.setCurrentStep(GENERATING_TRANSACTION);
                // Generate an unsigned transaction. See InterCompanyTradeState for further details.

/*
                TransactionState<ContractState> contractStateTransactionState = message.getData().getOutputStates().get(0);

                System.out.println("\n\n AFTER GETTING contractStateTransactionState");

                GrossTradeState grossTradedata = (GrossTradeState) contractStateTransactionState.getData();

                System.out.println("\n\n AFTER GETTING grossTradedata"+grossTradedata);

                final TransactionBuilder utx = grossTradedata.generateAgreement(notary);
*/

                final TransactionBuilder utx = message.get(0).getData().generateAgreement(notary);

                for(int i = 1; i < message.size() ; i++) {
                    utx.addOutputState(message.get(i));
                }
                // Add a timestamp as the contract code in PurchaseOrderContract mandates that ExampleStates are timestamped.
                final Instant currentTime = getServiceHub().getClock().instant();
                // As we are running in a distributed system, we allocate a 30 second time window for the transaction to
                // be timestamped by the Notary service.
                utx.setTime(currentTime, Duration.ofSeconds(30));

                System.out.println("\n\n AFTER CREATING TRANSACTION: "+utx);


                // Stage 5.
                progressTracker.setCurrentStep(SIGNING);
                // Sign the transaction.
                final SignedTransaction stx = utx.signWith(keyPair).toSignedTransaction(false);

                // Stage 6.
                progressTracker.setCurrentStep(SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE);
                // Send the state back across the wire to the designated counterparty.
                // ------------------------
                // Flow jumps to NettingInitiator.
                // ------------------------
                // Receive the signed transaction off the wire from the other party.

                System.out.println("\n\n BEFORE SENDING SINGED TRANSACTION OUTPUT STATES: "+stx.getTx().getOutputs());

                final SignedTransaction ntx = this.sendAndReceive(SignedTransaction.class, otherParty, stx)
                        .unwrap(data -> data);



                System.out.println("\n\n After Receiving final transaction Details Inputs : \n" +ntx.getTx().getInputs());
                System.out.println("\n\n After Receiving final transaction Details Outputs : \n" +ntx.getTx().getOutputs());
                // Stage 12.
                progressTracker.setCurrentStep(VERIFYING_TRANSACTION);
                // Validate transaction.
                // No need to allow for any omitted signatures as everyone should have signed.
                ntx.verifySignatures();
                // Check it's valid.
                ntx.toLedgerTransaction(getServiceHub()).verify();

                // Record the transaction.
                progressTracker.setCurrentStep(RECORDING);
                getServiceHub().recordTransactions(Collections.singletonList(ntx));
                System.out.println("*****************************\n\n\n EXAMPLE FLOW RESULT END");
                return new NetFlowResult.Success(String.format("Transaction id %s committed to ledger.", ntx.getId()));
            } catch (Throwable ex) {
                ex.printStackTrace(System.out);
                ex.printStackTrace();
                return new NetFlowResult.Failure(ex.getMessage());
            }
        }
    }

    public static class NetFlowResult {
        public static class Success extends com.example.flow.NettingTradeFlow.NetFlowResult {
            private String message;

            private Success(String message) {
                this.message = message;
            }

            @Override
            public String toString() {
                return String.format("Success(%s)", message);
            }
        }

        public static class Failure extends com.example.flow.NettingTradeFlow.NetFlowResult {
            private String message;

            private Failure(String message) {
                this.message = message;
            }

            @Override
            public String toString() {
                return String.format("Failure(%s)", message);
            }
        }
    }
}
