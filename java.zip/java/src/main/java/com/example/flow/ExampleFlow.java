package com.example.flow;

import co.paralleluniverse.fibers.Suspendable;
import com.example.contract.GrossTradeState;
import com.example.model.TradeStatusEnum;
import com.example.util.GrossTradeMatcher;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.DealState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.TransactionState;
import net.corda.core.crypto.CompositeKey;
import net.corda.core.crypto.CryptoUtilities;
import net.corda.core.crypto.DigitalSignature;
import net.corda.core.crypto.Party;
import net.corda.core.flows.FlowLogic;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.transactions.WireTransaction;
import net.corda.core.utilities.ProgressTracker;
import net.corda.flows.NotaryFlow;

import java.security.KeyPair;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.List;

import static com.example.model.TradeStatusEnum.MATCHED;
import static kotlin.collections.CollectionsKt.single;

/**
 * This is the "Hello World" of flows!
 * <p>
 * It is a generic flow which facilitates the workflow required for two parties; an [Initiator] and an [Acceptor],
 * to come to an agreement about some arbitrary data (in this case, a [PurchaseOrder]) encapsulated within a [DealState].
 * <p>
 * As this is just an example there's no way to handle any counter-proposals. The [Acceptor] always accepts the
 * proposed state assuming it satisfies the referenced [Contract]'s issuance constraints.
 * <p>
 * These flows have deliberately been implemented by using only the call() method for ease of understanding. In
 * practice we would recommend splitting up the various stages of the flow into sub-routines.
 * <p>
 * NB. All methods called within the [FlowLogic] sub-class need to be annotated with the @Suspendable annotation.
 * <p>
 * The flows below have been heavily commented to aid your understanding. It may also be worth reading the CorDapp
 * tutorial documentation on the Corda docsite (https://docs.corda.net) which includes a sequence diagram which clearly
 * explains each stage of the flow.
 */
public class ExampleFlow {
    public static class Initiator extends FlowLogic<ExampleFlowResult> {

        private final GrossTradeState grossTradeState;
        private final Party otherParty;
        // The progress tracker checkpoints each stage of the flow and outputs the specified messages when each
        // checkpoint is reached in the code. See the 'progressTracker.currentStep' expressions within the call()
        // function.
        private final ProgressTracker progressTracker = new ProgressTracker(
                CONSTRUCTING_OFFER,
                SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION,
                VERIFYING,
                SIGNING,
                NOTARY,
                RECORDING,
                SENDING_FINAL_TRANSACTION
        );

        private static final ProgressTracker.Step CONSTRUCTING_OFFER = new ProgressTracker.Step(
                "Constructing proposed purchase order.");
        private static final ProgressTracker.Step SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION = new ProgressTracker.Step(
                "Sending purchase order to seller for review, and receiving partially signed transaction from seller in return.");
        private static final ProgressTracker.Step VERIFYING = new ProgressTracker.Step(
                "Verifying signatures and contract constraints.");
        private static final ProgressTracker.Step SIGNING = new ProgressTracker.Step(
                "Signing transaction with our private key.");
        private static final ProgressTracker.Step NOTARY = new ProgressTracker.Step(
                "Obtaining notary signature.");
        private static final ProgressTracker.Step RECORDING = new ProgressTracker.Step(
                "Recording transaction in vault.");
        private static final ProgressTracker.Step SENDING_FINAL_TRANSACTION = new ProgressTracker.Step(
                "Sending fully signed transaction to seller.");

        public Initiator(GrossTradeState grossTradeState, Party otherParty) {
            this.grossTradeState = grossTradeState;
            this.otherParty = otherParty;
        }

        @Override
        public ProgressTracker getProgressTracker() {
            return progressTracker;
        }

        /**
         * The flow logic is encapsulated within the call() method.
         */
        @Suspendable
        @Override
        public ExampleFlowResult call() {
            // Naively, wrapped the whole flow in a try ... catch block so we can
            // push the exceptions back through the web API.
            try {
                // Prep.
                // Obtain a reference to our key pair. Currently, the only key pair used is the one which is registered with
                // the NetWorkMapService. In a future milestone release we'll implement HD key generation such that new keys
                // can be generated for each transaction.
                final KeyPair myKeyPair = getServiceHub().getLegalIdentityKey();
                // Obtain a reference to the notary we want to use and its public key.
                final Party notary = single(getServiceHub().getNetworkMapCache().getNotaryNodes()).getNotaryIdentity();
                final CompositeKey notaryPubKey = notary.getOwningKey();
                boolean isMatched = false;
                StateAndRef<GrossTradeState> matchedStateAndRef = null;
                // Stage 1.
                progressTracker.setCurrentStep(CONSTRUCTING_OFFER);
                // Construct a state object which encapsulates the PurchaseOrder object.
                // We add the public keys for us and the counterparty as well as a reference to the contract code.

                //NV :: check if there is any unmatched trade in the database for the incoming trade

                GrossTradeState matchedTradeState = grossTradeState;
                if (getServiceHub() != null) {
                    System.out.println("getServiceHub().getVaultService(): " + getServiceHub().getVaultService());

                    if (getServiceHub().getVaultService() != null) {
                        try {
                            System.out.println("Inside getServiceHub().getVaultService() != null");
                            System.out.println("getServiceHub(): " + getServiceHub().getVaultService().getCurrentVault());
                        }catch (Throwable e){
                            e.printStackTrace();
                        }


                        if (getServiceHub().getVaultService().getCurrentVault() != null) {
                            System.out.println("getServiceHub(): " + getServiceHub().getVaultService().getCurrentVault().getStates());
                            List<StateAndRef<ContractState>> stateAndRefList = getServiceHub().getVaultService().getCurrentVault().getStates();
                            if (stateAndRefList != null) {
                                System.out.println("StateAndRef: " + stateAndRefList);
                                 matchedStateAndRef = GrossTradeMatcher.matchGrossTrade(grossTradeState, stateAndRefList);
                                if(matchedStateAndRef != null) {

                                    TransactionState<GrossTradeState> transactionState = matchedStateAndRef.getState();
                                    GrossTradeState matchedState = transactionState.getData();

                                    matchedTradeState = matchedState.copy(MATCHED);
                                    System.out.println("Mathced State in Flow " + matchedTradeState);
                                    isMatched = true;
                                }
                            }
                        }
                    }
                }

                //End of NV
                final TransactionState offerMessage = new TransactionState<ContractState>(matchedTradeState, notary);

                // Stage 2.
                progressTracker.setCurrentStep(SENDING_OFFER_AND_RECEIVING_PARTIAL_TRANSACTION);
                // Send the state across the wire to the designated counterparty.
                // -----------------------
                // Flow jumps to Acceptor.
                // -----------------------
                // Receive the partially signed transaction off the wire from the other party.
                final SignedTransaction ptx = sendAndReceive(SignedTransaction.class, otherParty, offerMessage)
                        .unwrap(data -> data);

                // Stage 7.
                progressTracker.setCurrentStep(VERIFYING);
                // Check that the signature of the other party is valid.
                // Our signature and the Notary's signature are allowed to be omitted at this stage as this is only a
                // partially signed transaction.
                final WireTransaction wtx = ptx.verifySignatures(CryptoUtilities.getComposite(myKeyPair.getPublic()), notaryPubKey);

                if(isMatched) {
                    wtx.getInputs().add(matchedStateAndRef.getRef());
                }
                System.out.println("Inputs: "+ wtx.getInputs());
                System.out.println("Outputs: "+ wtx.getOutputs());

                // Run the contract's verify function.
                // We want to be sure that the PurchaseOrderState agreed upon is a valid instance of an PurchaseOrderContract, to do
                // this we need to run the contract's verify() function.
                System.out.println("Before Verifying");
                wtx.toLedgerTransaction(getServiceHub()).verify();
                System.out.println("After Verifying contract");
                // Stage 8.
                progressTracker.setCurrentStep(SIGNING);
                // Sign the transaction with our key pair and add it to the transaction.
                // We now have 'validation consensus'. We still require uniqueness consensus.
                // Technically validation consensus for this type of agreement implicitly provides uniqueness consensus.
                final DigitalSignature.WithKey mySig = CryptoUtilities.signWithECDSA(myKeyPair, ptx.getId().getBytes());
                final SignedTransaction vtx = ptx.plus(mySig);

                // Stage 9.
                progressTracker.setCurrentStep(NOTARY);
                // Obtain the notary's signature.
                // We do this by firing-off a sub-flow. This illustrates the power of protocols as reusable workflows.
                final DigitalSignature.WithKey notarySignature = subFlow(new NotaryFlow.Client(vtx, NotaryFlow.Client.Companion.tracker()), false);
                // Add the notary signature to the transaction.
                final SignedTransaction ntx = vtx.plus(notarySignature);

                // Stage 10.
                progressTracker.setCurrentStep(RECORDING);
                // Record the transaction in our vault.
                getServiceHub().recordTransactions(Collections.singletonList(ntx));

                // Stage 11.
                progressTracker.setCurrentStep(SENDING_FINAL_TRANSACTION);
                // Send a copy of the transaction to our counter-party.
                send(otherParty, ntx);

                System.out.println("* * * DB Results in vault* * *");

                List<StateAndRef<ContractState>> vaultStates = getServiceHub().getVaultService().getCurrentVault().getStates();

                for (StateAndRef stateAndRef : vaultStates) {
                  //  System.out.println("State: " + stateAndRef);
                    TransactionState<GrossTradeState> transactionState = stateAndRef.getState();
                    GrossTradeState tradeState = transactionState.getData();

                    System.out.println("\n \n TradeState from Database: " + tradeState);
                }

                return new ExampleFlowResult.Success(String.format("Transaction id %s committed to ledger.", ntx.getId()));
            } catch (Exception ex) {
                // Just catch all exception types.
                ex.printStackTrace();
                return new ExampleFlowResult.Failure(ex.getMessage());
            }
        }
    }

    public static class Acceptor extends FlowLogic<ExampleFlowResult> {

        private final Party otherParty;
        private final ProgressTracker progressTracker = new ProgressTracker(
                WAIT_FOR_AND_RECEIVE_PROPOSAL,
                GENERATING_TRANSACTION,
                SIGNING,
                SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE,
                VERIFYING_TRANSACTION,
                RECORDING
        );

        private static final ProgressTracker.Step WAIT_FOR_AND_RECEIVE_PROPOSAL = new ProgressTracker.Step(
                "Receiving proposed purchase order from buyer.");
        private static final ProgressTracker.Step GENERATING_TRANSACTION = new ProgressTracker.Step(
                "Generating transaction based on proposed purchase order.");
        private static final ProgressTracker.Step SIGNING = new ProgressTracker.Step(
                "Signing proposed transaction with our private key.");
        private static final ProgressTracker.Step SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE = new ProgressTracker.Step(
                "Sending partially signed transaction to buyer and wait for a response.");
        private static final ProgressTracker.Step VERIFYING_TRANSACTION = new ProgressTracker.Step(
                "Verifying signatures and contract constraints.");
        private static final ProgressTracker.Step RECORDING = new ProgressTracker.Step(
                "Recording transaction in vault.");

        public Acceptor(Party otherParty) {
            this.otherParty = otherParty;
        }

        @Override
        public ProgressTracker getProgressTracker() {
            return progressTracker;
        }

        @Suspendable
        @Override
        public ExampleFlowResult call() {
            try {
                // Prep.
                // Obtain a reference to our key pair.
                final KeyPair keyPair = getServiceHub().getLegalIdentityKey();

                // Stage 3.
                progressTracker.setCurrentStep(WAIT_FOR_AND_RECEIVE_PROPOSAL);
                // All messages come off the wire as UntrustworthyData. You need to 'unwrap' it. This is an appropriate
                // place to perform some validation over what you have just received.
                final TransactionState<DealState> message = this.receive(TransactionState.class, otherParty)
                        .unwrap(data -> (TransactionState<DealState>) data);

                System.out.println("* * *" + message);

                GrossTradeState inputGrossTrade = (GrossTradeState) message.getData();

                System.out.println("inputGrossTrade: " + inputGrossTrade);


                System.out.println("getServiceHub(): " + getServiceHub());

                if(!inputGrossTrade.getTradeStatusEnum().equals(TradeStatusEnum.MATCHED)) {
                    if (getServiceHub() != null) {
                        System.out.println("getServiceHub().getVaultService(): " + getServiceHub().getVaultService());

                        if (getServiceHub().getVaultService() != null) {
                            try {
                                System.out.println("Inside getServiceHub().getVaultService() != null");
                                System.out.println("getServiceHub(): " + getServiceHub().getVaultService().getCurrentVault());
                            } catch (Throwable e) {
                                e.printStackTrace();
                            }
                            if (getServiceHub().getVaultService().getCurrentVault() != null) {
                                System.out.println("getServiceHub(): " + getServiceHub().getVaultService().getCurrentVault().getStates());
                                List<StateAndRef<ContractState>> stateAndRefList = getServiceHub().getVaultService().getCurrentVault().getStates();
                                if (stateAndRefList != null) {
                                    System.out.println("StateAndRef: " + stateAndRefList);
                                    StateAndRef<GrossTradeState> matchedStateAndRef = GrossTradeMatcher.matchGrossTrade(inputGrossTrade, stateAndRefList);
                                    if(matchedStateAndRef != null && matchedStateAndRef.getState() != null) {
                                        System.out.println("Mathced State in Flow " + matchedStateAndRef.getState().getData());
                                    }
                                }


                            }
                        }
                    }
                }
                // Stage 4.
                progressTracker.setCurrentStep(GENERATING_TRANSACTION);
                // Generate an unsigned transaction. See PurchaseOrderState for further details.
                final TransactionBuilder utx = message.getData().generateAgreement(message.getNotary());
                // Add a timestamp as the contract code in PurchaseOrderContract mandates that ExampleStates are timestamped.
                final Instant currentTime = getServiceHub().getClock().instant();
                // As we are running in a distributed system, we allocate a 30 second time window for the transaction to
                // be timestamped by the Notary service.
                utx.setTime(currentTime, Duration.ofSeconds(30));



                // / Stage 5.
                progressTracker.setCurrentStep(SIGNING);
                // Sign the transaction.
                final SignedTransaction stx = utx.signWith(keyPair).toSignedTransaction(false);

                // Stage 6.
                progressTracker.setCurrentStep(SEND_TRANSACTION_AND_WAIT_FOR_RESPONSE);
                // Send the state back across the wire to the designated counterparty.
                // ------------------------
                // Flow jumps to Initiator.
                // ------------------------
                // Receive the signed transaction off the wire from the other party.
                final SignedTransaction ntx = this.sendAndReceive(SignedTransaction.class, otherParty, stx)
                        .unwrap(data -> data);

                // Stage 12.
                progressTracker.setCurrentStep(VERIFYING_TRANSACTION);
                // Validate transaction.
                // No need to allow for any omitted signatures as everyone should have signed.
                ntx.verifySignatures();
                // Check it's valid.
                ntx.toLedgerTransaction(getServiceHub()).verify();

                // Record the transaction.
                progressTracker.setCurrentStep(RECORDING);
                getServiceHub().recordTransactions(Collections.singletonList(ntx));

                System.out.println("* * * DB Results in vault* * *");

                List<StateAndRef<ContractState>> vaultStates = getServiceHub().getVaultService().getCurrentVault().getStates();

                for (StateAndRef stateAndRef : vaultStates) {
                 //   System.out.println("State: " + stateAndRef);
                    TransactionState<GrossTradeState> transactionState = stateAndRef.getState();
                    GrossTradeState tradeState = transactionState.getData();

                    System.out.println("\n \n TradeState from Database: " + tradeState);
                }

                return new ExampleFlowResult.Success(String.format("Transaction id %s committed to ledger.", ntx.getId()));
            } catch (Exception ex) {
                return new ExampleFlowResult.Failure(ex.getMessage());
            }
        }
    }

    public static class ExampleFlowResult {
        public static class Success extends com.example.flow.ExampleFlow.ExampleFlowResult {
            private String message;

            private Success(String message) {
                this.message = message;
            }

            @Override
            public String toString() {
                return String.format("Success(%s)", message);
            }
        }

        public static class Failure extends com.example.flow.ExampleFlow.ExampleFlowResult {
            private String message;

            private Failure(String message) {
                this.message = message;
            }

            @Override
            public String toString() {
                return String.format("Failure(%s)", message);
            }
        }
    }
}
