package com.example.util;

import com.example.contract.GrossTradeState;

/**
 * Created by Nitesh on 1/24/2017.
 */
public class NetTradeCalculator {

    public static GrossTradeState aggrigateNetTrades(GrossTradeState nettedTradeState, GrossTradeState inputTradeState) {

        System.out.println("Inside NetTradeCalculator");

        //Buyer
        if (inputTradeState.getBuyer().getName().equals("NodeA")) {

            nettedTradeState.getGrossTrade().setQuantity(nettedTradeState.getGrossTrade().getQuantity().add(inputTradeState.getGrossTrade().getQuantity()));
            nettedTradeState.getGrossTrade().setPrice(nettedTradeState.getGrossTrade().getPrice().add(inputTradeState.getGrossTrade().getPrice()));
            nettedTradeState.getGrossTrade().setAmount(nettedTradeState.getGrossTrade().getAmount().add(inputTradeState.getGrossTrade().getAmount()));

        } else {
            nettedTradeState.getGrossTrade().setQuantity(nettedTradeState.getGrossTrade().getQuantity().subtract(inputTradeState.getGrossTrade().getQuantity()));
            nettedTradeState.getGrossTrade().setPrice(nettedTradeState.getGrossTrade().getPrice().subtract(inputTradeState.getGrossTrade().getPrice()));
            nettedTradeState.getGrossTrade().setAmount(nettedTradeState.getGrossTrade().getAmount().subtract(inputTradeState.getGrossTrade().getAmount()));
        }

        return nettedTradeState;

    }

}
