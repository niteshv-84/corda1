package com.example.util;

import com.example.contract.GrossTradeState;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.TransactionState;

import java.util.List;

/**
 * Created by Nitesh on 1/24/2017.
 */
public class GrossTradeMatcher {

    public static StateAndRef<GrossTradeState> matchGrossTrade(GrossTradeState receivedTradeState, List<StateAndRef<ContractState>> vaultStates) {

        System.out.println("Inside matchGrossTrade");
        if (vaultStates != null && vaultStates.size() > 0) {
            System.out.println(vaultStates.get(0));

            for (StateAndRef stateAndRef : vaultStates) {
                System.out.println("State: " + stateAndRef);
                TransactionState<GrossTradeState> transactionState = stateAndRef.getState();
                GrossTradeState tradeState = transactionState.getData();

                System.out.println("TradeState from Database: "+tradeState);
                if(tradeState.equals(receivedTradeState)){
                    return stateAndRef;
                }

            }
        } else {
            System.out.println("Empty States");
        }
        System.out.println("No States matched");
        return null;
    }
}
