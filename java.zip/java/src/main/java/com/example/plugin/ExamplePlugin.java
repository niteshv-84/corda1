package com.example.plugin;

import com.esotericsoftware.kryo.Kryo;
import com.example.api.ExampleApi;
import com.example.contract.GrossTradeContract;
import com.example.contract.GrossTradeState;
import com.example.contract.TransactionStates;
import com.example.flow.ExampleFlow;
import com.example.flow.NettingTradeFlow;
import com.example.model.GrossTrade;
import com.example.model.TradeStatusEnum;
import com.example.service.ExampleService;
import net.corda.core.crypto.Party;
import net.corda.core.flows.IllegalFlowLogicException;
import net.corda.core.messaging.CordaRPCOps;
import net.corda.core.node.CordaPluginRegistry;
import net.corda.core.node.PluginServiceHub;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;

public class ExamplePlugin extends CordaPluginRegistry {
    /**
     * A list of classes that expose web APIs.
     */
    private final List<Function<CordaRPCOps, ?>> webApis = Collections.singletonList(ExampleApi::new);

    /**
     * A list of flows required for this CorDapp. Any flow which is invoked from from the web API needs to be
     * registered as an entry into this map. The map takes the form:
     * <p>
     * Name of the flow to be invoked -> Set of the parameter types passed into the flow.
     * <p>
     * E.g. In the case of this CorDapp:
     * <p>
     * "ExampleFlow.Initiator" -> Set(PurchaseOrderState, Party)
     * <p>
     * This map also acts as a white list. If a flow is invoked via the API and not registered correctly
     * here, then the flow state machine will _not_ invoke the flow. Instead, an exception will be raised.
     */
    /*private final Map<String, Set<String>> requiredFlows = Collections.singletonMap(
            ExampleFlow.Initiator.class.getName(),
            new HashSet<>(Arrays.asList(
                    GrossTradeState.class.getName(),
                    Party.class.getName()
            )));*/


    @Override
    public Map<String, Set<String>> getRequiredFlows() {
        Map<String, Set<String>> requiredFlows = new HashMap<String, Set<String>>();
        requiredFlows.put(
                ExampleFlow.Initiator.class.getName(),
                new HashSet<String>(Arrays.asList(
                        GrossTradeState.class.getName(),
                        Party.class.getName()
                )));
        requiredFlows.put(
                NettingTradeFlow.NettingInitiator.class.getName(),
                new HashSet<>(Arrays.asList(
                        Party.class.getName()
                )));
        return requiredFlows;
    }

    /**
     * A list of long lived services to be hosted within the node. Typically you would use these to register flow
     * factories that would be used when an initiating party attempts to communicate with our node using a particular
     * flow. See the [ExampleService.Service] class for an implementation.
     */
    private final List<Function<PluginServiceHub, ?>> servicePlugins = Collections.singletonList(ExampleService::new);

    /**
     * A list of directories in the resources directory that will be served by Jetty under /web.
     */
    private final Map<String, String> staticServeDirs = Collections.singletonMap(
            // This will serve the exampleWeb directory in resources to /web/example
            "example", getClass().getClassLoader().getResource("exampleWeb").toExternalForm()
    );

    @Override
    public List<Function<CordaRPCOps, ?>> getWebApis() {
        return webApis;
    }

    /*@Override
    public Map<String, Set<String>> getRequiredFlows() {
        return requiredFlows;
    }*/

    @Override
    public List<Function<PluginServiceHub, ?>> getServicePlugins() {
        return servicePlugins;
    }

    @Override
    public Map<String, String> getStaticServeDirs() {
        return staticServeDirs;
    }

    /**
     * Register required types with Kryo (our serialisation framework).
     */
    @Override
    public boolean registerRPCKryoTypes(Kryo kryo) {
        kryo.register(GrossTradeState.class);
        kryo.register(GrossTradeContract.class);
        kryo.register(GrossTrade.class);
        // kryo.register(PurchaseOrder.Address.class);
        kryo.register(Date.class);
        kryo.register(TradeStatusEnum.class);
        kryo.register(Currency.class);
        kryo.register(BigDecimal.class);
        kryo.register(TransactionStates.class);
        //  kryo.register(PurchaseOrder.Item.class);
        kryo.register(ExampleFlow.ExampleFlowResult.Success.class);
        kryo.register(ExampleFlow.ExampleFlowResult.Failure.class);

        kryo.register(NettingTradeFlow.NetFlowResult.Success.class);
        kryo.register(NettingTradeFlow.NetFlowResult.Failure.class);

        kryo.register(IllegalArgumentException.class);
        kryo.register(IllegalFlowLogicException.class);
        return true;
    }
}