package com.example.model;

/**
 * Created by Nitesh on 1/24/2017.
 */
public enum TradeStatusEnum {
    BOOKED, UNMATCHED, MATCHED, NETTED, CONSUMED
}
