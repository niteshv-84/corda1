package com.example.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Currency;
import java.util.Date;

/**
 * These files contain the data structures which the parties using this CorDapp will reach an agreement over. States can
 * support arbitrary complex object graphs. For a more complicated one, see
 * <p>
 * samples/irs-demo/src/kotlin/net/corda/irs/contract/IRS.kt
 * <p>
 * in the main Corda repo (http://github.com/corda/corda).
 * <p>
 * These structures could be embedded within the ContractState. However, for clarity, we have moved them in to a
 * separate file.
 */

/**
 * A simple class representing a purchase order.
 */
public class GrossTrade {


    public GrossTrade() {

    }

    String tradeId;
    private Date tradeDate;
    private Date valueDate;
    private String securityID;
    private Currency currency;
    private BigDecimal quantity;
    private BigDecimal price;
    private BigDecimal amount;


    public GrossTrade(String tradeId, Date tradeDate, Date valueDate,
                      String securityID, Currency currency, BigDecimal quantity,
                      BigDecimal price, BigDecimal amount) {
        this.tradeId = tradeId;
        this.tradeDate = tradeDate;
        this.valueDate = valueDate;
        this.securityID = securityID;
        this.currency = currency;

        this.quantity = quantity;
        this.price = price;
        this.amount = quantity.multiply(price);
    }

    public String getTradeId() {
        return tradeId;
    }

    public void setTradeId(String tradeId) {
        this.tradeId = tradeId;
    }

    public Date getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(Date tradeDate) {
        this.tradeDate = tradeDate;
    }

    public Date getValueDate() {
        return valueDate;
    }

    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }

    public String getSecurityID() {
        return securityID;
    }

    public void setSecurityID(String securityID) {
        this.securityID = securityID;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GrossTrade)) return false;

        GrossTrade that = (GrossTrade) o;

        //if (!getTradeDate().equals(that.getTradeDate())) return false;
        //if (!getValueDate().equals(that.getValueDate())) return false;
        if (!getSecurityID().equals(that.getSecurityID())) return false;
        if (!getCurrency().equals(that.getCurrency())) return false;
        if (!getQuantity().equals(that.getQuantity())) return false;
        if (!getPrice().equals(that.getPrice())) return false;
        return getAmount().equals(that.getAmount());
    }

    @Override
    public int hashCode() {
        int result = getTradeDate().hashCode();
        result = 31 * result + getValueDate().hashCode();
        result = 31 * result + getSecurityID().hashCode();
        result = 31 * result + getCurrency().hashCode();
        result = 31 * result + getQuantity().hashCode();
        result = 31 * result + getPrice().hashCode();
        result = 31 * result + getAmount().hashCode();
        return result;
    }


    @Override
    public String toString() {
        return "GrossTrade{" +
                "tradeId='" + tradeId + '\'' +
                ", tradeDate=" + tradeDate +
                ", valueDate=" + valueDate +
                ", securityID='" + securityID + '\'' +
                ", currency=" + currency +
                ", quantity=" + quantity +
                ", price=" + price +
                ", amount=" + amount +
                '}';
    }
}