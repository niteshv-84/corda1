package com.example.api;

import com.example.contract.GrossTradeContract;
import com.example.contract.GrossTradeState;
import com.example.flow.ExampleFlow;
import com.example.flow.NettingTradeFlow;
import com.example.model.GrossTrade;
import com.example.model.TradeStatusEnum;
import net.corda.core.contracts.ContractState;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.crypto.Party;
import net.corda.core.messaging.CordaRPCOps;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.math.BigDecimal;
import java.util.Currency;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import static java.util.Collections.singletonMap;
import static java.util.stream.Collectors.toList;

// This API is accessible from /api/example. All paths specified below are relative to it.
@Path("example")
public class ExampleApi {
    private final CordaRPCOps services;
    private final String myLegalName;

    public ExampleApi(CordaRPCOps services) {
        this.services = services;
        this.myLegalName = services.nodeIdentity().getLegalIdentity().getName();
    }

    /**
     * Returns the party name of the node providing this end-point.
     */
    @GET
    @Path("me")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, String> whoami() { return singletonMap("me", myLegalName); }

    /**
     * Returns all parties registered with the [NetworkMapService]. The names can be used to look up identities by
     * using the [IdentityService].
     */
    @GET
    @Path("peers")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, List<String>> getPeers() {
        final String NOTARY_NAME = "Controller";
        return singletonMap(
                "peers",
                services.networkMapUpdates().getFirst()
                        .stream()
                        .map(node -> node.getLegalIdentity().getName())
                        .filter(name -> !name.equals(myLegalName) && !name.equals(NOTARY_NAME))
                        .collect(toList()));
    }

    /**
     * Displays all purchase order states that exist in the vault.
     */
    @GET
    @Path("trade-details")
    @Produces(MediaType.APPLICATION_JSON)
    public List<StateAndRef<ContractState>> getTrades() {


            return  services.vaultAndUpdates().getFirst();
        }



    /**
     * This should only be called from the 'buyer' node. It initiates a flow to agree a purchase order with a
     * seller. Once the flow finishes it will have written the purchase order to ledger. Both the buyer and the
     * seller will be able to see it when calling /api/example/purchase-orders on their respective nodes.
     *
     * This end-point takes a Party name parameter as part of the path. If the serving node can't find the other party
     * in its network map cache, it will return an HTTP bad request.
     *
     * The flow is invoked asynchronously. It returns a future when the flow's call() method returns.
     */
    @PUT
    @Path("{party}/create-purchase-order")
    public Response createGrossTrade(GrossTrade grossTrade, @PathParam("party") String partyName) throws InterruptedException, ExecutionException {
        final Party otherParty = services.partyFromName(partyName);

        GrossTrade trade = new GrossTrade();
        trade.setAmount(new BigDecimal("100"));
        trade.setCurrency(Currency.getInstance("USD"));
        trade.setPrice(new BigDecimal("100"));
        trade.setQuantity(new BigDecimal("100"));
        trade.setTradeId("123");
        trade.setTradeDate(new Date());
        trade.setValueDate(new Date());

        grossTrade = trade;

        if (otherParty == null) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        final GrossTradeState state = new GrossTradeState(
                grossTrade,
                TradeStatusEnum.BOOKED,
                services.nodeIdentity().getLegalIdentity(),
                otherParty,
                new GrossTradeContract());

        // The line below blocks and waits for the flow to return.
        final ExampleFlow.ExampleFlowResult result = services
                .startFlowDynamic(ExampleFlow.Initiator.class, state, otherParty)
                .getReturnValue()
                .toBlocking()
                .first();

        final Response.Status status;
        if (result instanceof ExampleFlow.ExampleFlowResult.Success) {
            status = Response.Status.CREATED;
        } else {
            status = Response.Status.BAD_REQUEST;
        }

        return Response
                .status(status)
                .entity(result.toString())
                .build();
    }


    @GET
    @Path("{seller}/{buyer}/{quantity}/{price}/{product}/book-gross-trade")
    public Response bookGrossTrade(@PathParam("seller") String seller ,@PathParam("buyer") String buyer , @PathParam("quantity") String quantity , @PathParam("price") String price , @PathParam("product") String product) throws InterruptedException, ExecutionException {

        Party otherParty  ;

        if( services.nodeIdentity().getLegalIdentity().getName().equals("NodeA")){
            otherParty = services.partyFromName("NodeB");
        }else
        {
            otherParty = services.partyFromName("NodeA");
        }
        final Party sellerParty = services.partyFromName(seller);
        final Party buyerParty = services.partyFromName(buyer);

        GrossTrade trade = new GrossTrade();

        trade.setCurrency(Currency.getInstance("USD"));
        trade.setPrice(new BigDecimal(price));
        trade.setQuantity(new BigDecimal(quantity));
        trade.setSecurityID(product);
        System.out.println("");
        String id = ""+System.currentTimeMillis();
        trade.setTradeId(id);
        trade.setTradeDate(new Date());
        trade.setValueDate(new Date());
        trade.setAmount(trade.getPrice().multiply(trade.getQuantity()));

        GrossTrade grossTrade = trade;

        System.out.println("grossTrade Id: "+ id);

        System.out.println("Buyer: "+ buyerParty +" Seller "+ sellerParty + " otherParty : " + otherParty);
        /*if (otherParty == null) {
            return null;// Response.status(Response.Status.BAD_REQUEST).build();
        }*/

        final GrossTradeState state = new GrossTradeState(
                grossTrade,
                TradeStatusEnum.BOOKED,
                buyerParty,
                sellerParty,
                new GrossTradeContract());

        // The line below blocks and waits for the flow to return.
        final ExampleFlow.ExampleFlowResult result = services
                .startFlowDynamic(ExampleFlow.Initiator.class, state, otherParty)
                .getReturnValue()
                .toBlocking()
                .first();

        final Response.Status status;
        if (result instanceof ExampleFlow.ExampleFlowResult.Success) {
            status = Response.Status.CREATED;
        } else {
            status = Response.Status.BAD_REQUEST;
        }
        System.out.print("* ********************************");
        return null;//services.vaultAndUpdates().getFirst();
    }

    @GET
    @Path("/{product}/net-trade")
    public Response netTrades(@PathParam("product") String product ) throws InterruptedException, ExecutionException {

        Party otherParty  ;
        System.out.println("Starting netTrades");
        if( services.nodeIdentity().getLegalIdentity().getName().equals("NodeA")){
            otherParty = services.partyFromName("NodeB");
        }else
        {
            otherParty = services.partyFromName("NodeA");
        }
        final Party nodeA = services.partyFromName("NodeA");
        final Party nodeB = services.partyFromName("NodeB");

        System.out.println("Starting netTrades");
        // The line below blocks and waits for the flow to return.
        final NettingTradeFlow.NetFlowResult result = services
                .startFlowDynamic(NettingTradeFlow.NettingInitiator.class, nodeA, nodeB , otherParty)
                .getReturnValue()
                .toBlocking()
                .first();


        final Response.Status status;
        if (result instanceof NettingTradeFlow.NetFlowResult.Success) {
            status = Response.Status.CREATED;
        } else {
            status = Response.Status.BAD_REQUEST;
        }
        System.out.print("* ********************************");
        return null;//services.vaultAndUpdates().getFirst();
    }

}